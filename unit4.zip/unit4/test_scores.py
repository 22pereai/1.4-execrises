#!/usr/bin/env python3

def display_welcome():
    print("The Test Scores program")
    print("Enter 'x' to exit")
    print("")

def get_scores():
    score_list = []
    while True:
        score = input("Enter test score: ")
        if score == "x":
            return  score_list
        else:
            score = int(score)
            if score >= 0 and score <= 100:
                score_list.append(score)
            else:
                print("Test score must be from 0 through 100. " +
                      "Score discarded. Try again.")

def process_scores(score_list):
    score_total = 0 # initializes the score total
    count = len(score_list) # sets a variable to the total # of scores for use in calculating length and average
    # print(score_list)
    for i in score_list: # handles the combination of the scores into a single number.
        score_total = score_total + i
        count + 1
    average = score_total / count
    score_list.sort(reverse = True)
    high = score_list[0]
    score_list.sort(reverse = True)
    eoo = count % 2
    if eoo != 0:
        median = score_list[eoo]
    else:
        m1 = (count // 2) - 1
        m2 = (count // 2)
       # print(m1)
       # print(m2)
       # print(score_list[m1])
       # print(score_list[m2])
        median = (score_list[m1] + score_list[m2]) / 2
    return score_total, count, average, high, median



def main():
    display_welcome()
    score_list = get_scores()
    score_total, count, average, high, median = process_scores(score_list)
    print("Total:", score_total)
    print("# of Scores:", count)
    print("Average Score:", average)
    print("High Score:", high)
    print("Median Score:", median)
    print("Bye!")

# if started as the main module, call the main function
if __name__ == "__main__":
    main()


